/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License. See License.txt in the project root for
 * license information.
 */
package com.microsoft.cse.adlsgen2;

import java.io.IOException;

import com.microsoft.azure.AzureEnvironment;
import com.microsoft.azure.credentials.ApplicationTokenCredentials;

/**
 * Token based credentials for use with a REST Service Client.
 */
public class StorageTokenCredentials extends ApplicationTokenCredentials {

    /**
     * Initializes a new instance of the ApplicationTokenCredentials.
     *
     * @param clientId    the active directory application client id. Also known as
     *                    Application Id which Identifies the application that is
     *                    using the token.
     * @param domain      the domain or tenant id containing this application.
     * @param secret      the authentication secret for the application.
     * @param environment the Azure environment to authenticate with. If null is
     *                    provided, AzureEnvironment.AZURE will be used.
     */
    public StorageTokenCredentials(String clientId, String domain, String secret, AzureEnvironment environment) {
        super(clientId, domain, secret, environment); // defer token acquisition
    }

    /**
     * Initializes a new instance of the ApplicationTokenCredentials.
     *
     * @param clientId    the active directory application client id. Also known as
     *                    Application Id which Identifies the application that is
     *                    using the token.
     * @param domain      the domain or tenant id containing this application.
     * @param certificate the PKCS12 certificate file content
     * @param password    the password to the certificate file
     * @param environment the Azure environment to authenticate with. If null is
     *                    provided, AzureEnvironment.AZURE will be used.
     */
    public StorageTokenCredentials(String clientId, String domain, byte[] certificate, String password, AzureEnvironment environment) {
        super(clientId, domain, certificate, password, environment);
    }

    @Override
    public synchronized String getToken(String resource) throws IOException {
        //Ignores received resource
        return super.getToken("https://storage.azure.com");
    }
}