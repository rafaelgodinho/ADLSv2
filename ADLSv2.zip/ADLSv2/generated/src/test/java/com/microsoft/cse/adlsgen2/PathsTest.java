package com.microsoft.cse.adlsgen2;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.TimeUnit;

import com.google.common.base.Stopwatch;
import com.microsoft.azure.AzureEnvironment;
import com.microsoft.cse.adlsgen2.implementation.DataLakeStorageClientImpl;
import com.microsoft.rest.RestClient;
import com.microsoft.rest.ServiceResponseBuilder;
import com.microsoft.rest.retry.ExponentialBackoffRetryStrategy;
import com.microsoft.rest.retry.RetryStrategy;
import com.microsoft.rest.serializer.JacksonAdapter;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import okhttp3.logging.HttpLoggingInterceptor;

/**
 * Unit test for simple App.
 */
public class PathsTest extends TestCase {
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public PathsTest(String testName) {
        super(testName);
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( PathsTest.class );
    }

    private byte[] toByteArray(BufferedReader input) throws IOException{
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        long count = 0;
        int reads = input.read();
       
        try {
            while(reads != -1){
                baos.write(reads);
                reads = input.read();
                count++;
            }
        } catch(Exception e) {
            System.out.println("[toByteArray] Exception has happened - Count: " + count);
            e.printStackTrace();
            throw new IOException(e.getMessage());
        }

        System.out.println("[toByteArray] Count: " + count);

        return baos.toByteArray();
    }

	private DataLakeStorageClient createClientNoLog() {
        RetryStrategy retryStrategy = new ExponentialBackoffRetryStrategy();

        RestClient restClient = new RestClient.Builder()
            .withBaseUrl(TestSecrets.getAccountUri())
            .withResponseBuilderFactory(new ServiceResponseBuilder.Factory())
                .withSerializerAdapter(new JacksonAdapter())
            .withCredentials(getCredentials())
            .withRetryStrategy(retryStrategy)
            .build();

        DataLakeStorageClientImpl adlsClient = new DataLakeStorageClientImpl(restClient)
            .withAccountName(TestSecrets.getAccountName())
            .withDnsSuffix(TestSecrets.getAccountUri())
            .withXMsVersion("2018-06-17");

        return adlsClient;
    }

	private StorageTokenCredentials getCredentials() {
		StorageTokenCredentials credentials = new StorageTokenCredentials(TestSecrets.getClientId(),
                TestSecrets.getTenantId(), 
                TestSecrets.getClientSecret(), 
                AzureEnvironment.AZURE);

        return credentials;
    }

    private DataLakeStorageClient createClientWithLog() {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        RetryStrategy retryStrategy = new ExponentialBackoffRetryStrategy();

        RestClient restClient = new RestClient.Builder()
            .withBaseUrl(TestSecrets.getAccountUri())
            .withResponseBuilderFactory(new ServiceResponseBuilder.Factory())
                .withSerializerAdapter(new JacksonAdapter())
            .withCredentials(getCredentials())
            .withRetryStrategy(retryStrategy)
            .withNetworkInterceptor(interceptor)
            .build();

        DataLakeStorageClientImpl adlsClient = new DataLakeStorageClientImpl(restClient)
            .withAccountName(TestSecrets.getAccountName())
            .withDnsSuffix(TestSecrets.getAccountUri())
            .withXMsVersion("2018-06-17");

        return adlsClient;
    }

    //Download a file using classes from java.net.* package
    public void testDownloadJavaNet() {
        Stopwatch timer = Stopwatch.createStarted();
        try {
            String filesystem = "mydata";
            String path = "directory1234/medium.txt";

            URL url = new URL(TestSecrets.getAccountUri() + "/" + filesystem + "/" + path);

            URLConnection uc = url.openConnection();
            uc.setRequestProperty("Authorization", "Bearer " + getCredentials().getToken(null));

            InputStream content = (InputStream)uc.getInputStream();
            BufferedReader in = new BufferedReader (new InputStreamReader(content));
            String fileContent = new String(toByteArray(in));

            System.out.println("[testDownloadJavaNet] Bytes read: " + fileContent.length());

            content.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        timer.stop();
        System.out.println("[testDownloadJavaNet] Ellapsed time: " + timer.elapsed(TimeUnit.MILLISECONDS));
    }

    public void testDownloadWithLog() {
        Stopwatch timer = Stopwatch.createStarted();
        try {
            String filesystem = "mydata";
            String path = "directory1234/medium.txt";

            DataLakeStorageClient client = createClientWithLog();

            InputStream inputStream = client.paths().read(filesystem, path);
            BufferedReader in = new BufferedReader (new InputStreamReader(inputStream));
            String fileContent = new String(toByteArray(in));

            in.close();
            inputStream.close();

            timer.stop();
            assertNotNull("[testDownloadWithLog] FileContent must not be null", fileContent);
            System.out.println("[testDownloadWithLog] Bytes read: " + fileContent.length());
            System.out.println("[testDownloadWithLog] Ellapsed time: " + timer.elapsed(TimeUnit.MILLISECONDS));
        } catch (Exception e) {
            timer.stop();
            System.out.println("[testDownloadWithLog] Exception - Ellapsed time: " + timer.elapsed(TimeUnit.MILLISECONDS));
            e.printStackTrace();
            fail("[testDownloadWithLog] An exception happened");
        }
    }

    public void testDownloadNoLog() {
        Stopwatch timer = Stopwatch.createStarted();
        try {
            String filesystem = "mydata";
            String path = "directory1234/medium.txt";

            DataLakeStorageClient client = createClientNoLog();

            InputStream inputStream = client.paths().read(filesystem, path);
            BufferedReader in = new BufferedReader (new InputStreamReader(inputStream));
            String fileContent = new String(toByteArray(in));

            in.close();
            inputStream.close();

            timer.stop();
            assertNotNull("[testDownloadNoLog] FileContent must not be null", fileContent);
            System.out.println("[testDownloadNoLog] Bytes read: " + fileContent.length());
            System.out.println("[testDownloadNoLog] Ellapsed time: " + timer.elapsed(TimeUnit.MILLISECONDS));
        } catch (Exception e) {
            timer.stop();
            System.out.println("[testDownloadNoLog] Exception - Ellapsed time: " + timer.elapsed(TimeUnit.MILLISECONDS));
            e.printStackTrace();
            fail("[testDownloadNoLog] An exception happened");
        }
    } 
}