package com.microsoft.cse.adlsgen2;

public class TestSecrets
{
    final static private String _tenantId = "";
    final static private String _clientId = "";
    final static private String _clientSecret = "";
    final static private String _accountName = "";
    final static private String _accountUri = "https://" + _accountName + ".dfs.core.windows.net";

    public static String getTenantId() { return _tenantId; }
    public static String getClientId() { return _clientId; }
    public static String getClientSecret() { return _clientSecret; }
    public static String getAccountUri() { return _accountUri; }
    public static String getAccountName() { return _accountName; }
}